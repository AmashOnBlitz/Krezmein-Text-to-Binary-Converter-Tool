﻿#include <iostream>
#include <bitset>
#include <string>
#include <regex>
#include <chrono>
#include <thread>

// ANSI color codes
const std::string RESET = "\033[0m";
const std::string RED = "\033[31m";
const std::string GREEN = "\033[32m";
const std::string YELLOW = "\033[33m";
const std::string BLUE = "\033[34m";
const std::string CYAN = "\033[36m";
const std::string WHITE = "\033[37m";
const std::string BOLD = "\033[1m";
const std::string ITALIC = "\033[3m";

// Function to clear the screen
void clearScreen() {
#ifdef _WIN32
    system("cls");
#else
    system("clear");
#endif
}

// Function to display the simplified title
void displayTitle() {
    clearScreen();
    std::cout << CYAN << R"(
 _  __                            _         _____         _     _        
| |/ /_ __ ___ _____ __ ___   ___(_)_ __   |_   _|____  _| |_  | |_ ___  
| ' /| '__/ _ \_  / '_ ` _ \ / _ \ | '_ \    | |/ _ \ \/ / __| | __/ _ \ 
| . \| | |  __// /| | | | | |  __/ | | | |   | |  __/>  <| |_  | || (_) |
|_|\_\_|  \___/___|_| |_| |_|\___|_|_| |_|   |_|\___/_/\_\\__|  \__\___/ 
| __ )(_)_ __   __ _ _ __ _   _                                          
|  _ \| | '_ \ / _` | '__| | | |                                         
| |_) | | | | | (_| | |  | |_| |                                         
|____/|_|_| |_|\__,_|_|   \__, |                                         
                          |___/ 

)" << YELLOW << BOLD << "Krezmein Text to Binary Converter and Vice Versa\n" << ITALIC << "Made by Amash On Blitz\n\n" << RESET;
}

// Function to simulate loading animation
void loadingAnimation() {
    const std::string loadingChars = "|/-\\";
    for (int i = 0; i < 20; ++i) {
        std::cout << YELLOW << "\rLoading " << loadingChars[i % loadingChars.size()] << " " << RESET;
        std::flush(std::cout);
        std::this_thread::sleep_for(std::chrono::milliseconds(100));
    }
    std::cout << std::endl;
}

// Function to convert text to binary
std::string textToBinary(const std::string& text) {
    std::string binary = "";
    for (char c : text) {
        binary += std::bitset<8>(c).to_string() + " "; // Convert each character to an 8-bit binary
    }
    return binary;
}

// Function to convert binary to text
std::string binaryToText(const std::string& binary) {
    std::string text = "";
    std::regex binaryPattern("([01]{8})"); // Match 8 bits of binary at a time
    std::sregex_iterator it(binary.begin(), binary.end(), binaryPattern);
    std::sregex_iterator end;

    while (it != end) {
        std::bitset<8> bits(it->str());
        text += static_cast<char>(bits.to_ulong()); // Convert 8 bits to a character
        ++it;
    }

    return text;
}

int main() {
    displayTitle();

    while (true) {
        std::cout << YELLOW << "Choose an option:\n" << RESET;
        std::cout << BLUE << "1. Convert Text to Binary\n";
        std::cout << "2. Convert Binary to Text\n";
        std::cout << "3. Exit\n" << RESET;
        std::cout << GREEN << "Enter your choice: " << RESET;

        int choice;
        std::cin >> choice;
        std::cin.ignore(); // Ignore the newline left by std::cin

        if (choice == 1) {
            std::cout << GREEN << "Enter text to convert to binary: " << RESET;
            std::string text;
            std::getline(std::cin, text);

            loadingAnimation();
            std::string binary = textToBinary(text);

            std::cout << CYAN << "Binary representation:\n" << BOLD << binary << RESET << "\n";

        }
        else if (choice == 2) {
            std::cout << GREEN << "Enter binary string (8-bit groups separated by spaces) to convert to text:\n" << RESET;
            std::string binary;
            std::getline(std::cin, binary);

            loadingAnimation();
            std::string text = binaryToText(binary);

            std::cout << CYAN << "Original text: " << BOLD << text << RESET << "\n";

        }
        else if (choice == 3) {
            std::cout << RED << "\nExiting... Thank you for using the tool!" << RESET << std::endl;
            break;
        }
        else {
            std::cout << RED << "Invalid choice. Please try again.\n" << RESET;
        }
    }

    return 0;
}
